    python3 run.py --datamode=optimized --mode=corun
